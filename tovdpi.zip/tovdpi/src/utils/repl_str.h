char *repl_str(const char *str, const char *from, const char *to);
